import {
    Card,
    CardText,
    CardTitle,
    Button,
    Row,
    Col,
  } from "reactstrap";

import { Link } from "react-router-dom";

const Cards = () => {
    return (
      <div>
        <Row>
          <h5 className="mb-3 mt-3">Sensor Groups</h5>
          <Col md="6" lg="4">
            <Card body className="text-center">
              <CardTitle tag="h5">Environmental Monitoring</CardTitle>
              <div>
                <Link to="/1">
                    <Button color="light-danger">Visit</Button>
                </Link>
              </div>
            </Card>
          </Col>
          <Col md="6" lg="4">
            <Card body className="text-center">
              <CardTitle tag="h5">Hypothermic Sensors</CardTitle>
              <div>
                <Link to="/2">
                    <Button color="light-danger">Visit</Button>
                </Link>
              </div>
            </Card>
          </Col>
          <Col md="6" lg="4">
            <Card body className="text-center">
              <CardTitle tag="h5">Heartbeat Sensors</CardTitle>
              <div>
                <Link to="/3">
                    <Button color="light-danger">Visit</Button>
                </Link>
              </div>
            </Card>
          </Col>
          <Col md="6" lg="4">
            <Card body className="text-center">
              <CardTitle tag="h5">Sleep Monitoring</CardTitle>
              <div>
                <Link to="/4">
                    <Button color="light-danger">Visit</Button>
                </Link>
              </div>
            </Card>
          </Col>
          <Col md="6" lg="4">
            <Card body className="text-center">
              <CardTitle tag="h5">RFID Tags</CardTitle>
              <div>
                <Link to="/5">
                    <Button color="light-danger">Visit</Button>
                </Link>
              </div>
            </Card>
          </Col>
     
        </Row>
      </div>
    );
  };
  
  export default Cards;
  
